<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <ul>
        <li><a href="/gbphp/publc/index.php?c=user&a=all&o=0&l=10">Пользователи</a></li>
        <li><a href="/gbphp/publc/index.php?c=good&a=all&o=0&l=10">Все товары</a></li>
    </ul>

    <?= $content ?>
</body>
</html>