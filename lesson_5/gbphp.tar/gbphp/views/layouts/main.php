<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
    <ul>
        <li><a href="/?c=user&a=all">Пользователи</a></li>
        <li><a href="/?c=good&a=all">Товары</a></li>
        <li><a href="/?c=good&a=add">Добавление товара</a></li>
    </ul>

    <?= $content ?>
</body>
</html>