<?php
/** @var \App\models\Good $good */
?>

<h1><?= $good->name ?></h1>
<p>
    <?= $good->info ?>
</p>

